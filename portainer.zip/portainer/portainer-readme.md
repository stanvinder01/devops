# Portainer
## Introduction
Portainer Community Edition 2.0 is a powerful, open-source toolset that allows you to easily build and manage containers in Docker, Swarm, Kubernetes and Azure ACI.

Portainer simplifies container management and troubleshooting problems. Portainer works by hiding the complexity that makes managing containers difficult behind an easy to use GUI. 
 

## Deploying Portainer Stack

### Deploy Portainer in local(Windows 10)

1. Use the given docker stack file for portainer "portainer-ce-agent-stack.yml" 
    ```
    docker stack deploy -c ./portainer-ce-agent-local-stack.yml portainer-stack
    ```
2. Portainer should be accessible from URL http://localhost:9000 and create admin user for first time.

    Reference:

    https://gist.github.com/SeanSobey/344edd228922ffd4266ae7d451421ab6

### Deploy Portainer to Docker Swarm(Linux)

#### Pre-requisites

1. Make sure docker is running and running in swarm mode
2. At least 1GB memory and 0.5 core is allocated for docker

To deploy Portainer stack to docker swarm peform following steps:

1. Clone the [nrg-docker-utils](https://digital-it-apps@dev.azure.com/digital-it-apps/Digital-IT-Projects/_git/nrg-docker-utils) repo to a local directory.
    ```
    git clone https://digital-it-apps@dev.azure.com/digital-it-apps/Digital-IT-Projects/_git/nrg-docker-utils

    cd nrg-docker-utils
    ```

2. Update file portainer/portainer-agent-stack.yml to reflect correct docker installation path for volumes.
      ```
      - /var/run/docker.sock:/var/run/docker.sock
      - /apps01/docker/volumes:/var/lib/docker/volumes
      ```
3. Set following environment variables which needs to be set for efk-stack.yml file.

    PowerShell:
    ```
    PS > $env:PORTAINER_AGENT_CPU_LIMIT="0.25"
    PS > $env:PORTAINER_AGENT_MEM_LIMIT="256M"
    PS > $env:PORTAINER_PORT="3450"
    PS > $env:PORTAINER_CPU_LIMIT="0.25"
    PS > $env:PORTAINER_MEM_LIMIT="256M"
    ```

    Linux Bash:
    ```
    export PORTAINER_AGENT_CPU_LIMIT="0.25"
    export PORTAINER_AGENT_MEM_LIMIT="256M"
    export PORTAINER_PORT="3450"
    export PORTAINER_CPU_LIMIT="0.25"
    export PORTAINER_MEM_LIMIT="256M"
    ```
4. Deploy the stack to docker swarm
    ```
    docker deploy stack -c .\portainer\portainer-agent-stack.yml portainer
    ```
5. You can also run single command instead of step 3 and 4.

    Windows PowerShell:
    ```
    PS > $env:PORTAINER_AGENT_CPU_LIMIT="0.25"; $env:PORTAINER_AGENT_MEM_LIMIT="256M"; $env:PORTAINER_PORT="3450"; $env:PORTAINER_CPU_LIMIT="0.25"; $env:PORTAINER_MEM_LIMIT="256M"; docker deploy stack -c .\portainer\portainer-agent-stack.yml portainer
    ```

    Linux Bash:
    ```
    env PORTAINER_AGENT_CPU_LIMIT="0.25" PORTAINER_AGENT_MEM_LIMIT="256M" PORTAINER_PORT="3450" PORTAINER_CPU_LIMIT="0.25" PORTAINER_MEM_LIMIT="256M" docker deploy stack -c ./portainer/portainer-agent-stack.yml portainer
    ```
6. Portainer should be accessible from URL http://\<hostname\>:3450 and set admin password for first time.